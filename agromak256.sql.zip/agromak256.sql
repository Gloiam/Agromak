-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 03, 2023 at 08:44 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `agromak256`
--

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE IF NOT EXISTS `farmer` (
  `user_id` int(3) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `contact` int(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `farmer`
--

INSERT INTO `farmer` (`user_id`, `username`, `contact`, `address`, `dob`, `gender`, `password`) VALUES
(13, 'carol', 756322756, 'Banda', '2001-02-05', 'female', 'carol'),
(14, 'gloria', 756006400, 'kitintale', '0090-06-02', 'female', 'gloria'),
(15, 'coleb', 876554433, 'Banda', '2023-09-06', 'male', 'coleb'),
(16, 'JACHWICH PRINCE ANTH', 740700954, 'KITINTALE', '2002-06-18', 'male', '1806'),
(17, 'caro', 2147483647, 'kitintale', '2023-08-01', 'female', 'carol');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `pay_id` int(3) NOT NULL AUTO_INCREMENT,
  `payname` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `quantity` int(20) NOT NULL,
  `amount` int(20) NOT NULL,
  `p_id` int(3) NOT NULL,
  `user_id` int(3) NOT NULL,
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pay_id`, `payname`, `date`, `quantity`, `amount`, `p_id`, `user_id`) VALUES
(1, 'gates foods', '2023-07-12', 25, 100000, 20, 5),
(4, 'Paul''s grocery', '2023-08-01', 13, 109000, 11, 12);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` int(3) NOT NULL AUTO_INCREMENT,
  `pname` varchar(20) NOT NULL,
  `pquantity` int(20) NOT NULL,
  `pprice` varchar(20) NOT NULL,
  `user_id` int(3) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `pname`, `pquantity`, `pprice`, `user_id`) VALUES
(1, 'rice', 100, '20000', 0),
(2, 'rice', 12299, '19000', 0),
(3, '', 0, '', 0),
(4, '', 0, '', 0),
(5, 'banana', 20, '100000', 0),
(6, '', 0, '', 0),
(7, '', 0, '', 0),
(8, '', 0, '', 0),
(9, '', 0, '', 0),
(10, '', 0, '', 0),
(11, 'peas', 20, '150000', 0),
(12, '', 0, '', 0),
(13, '', 0, '', 0),
(14, '', 0, '', 0),
(15, '', 0, '', 0),
(16, '', 0, '', 0),
(17, '', 0, '', 0),
(18, '', 0, '', 0),
(20, 'cow peas', 20, '150000', 0),
(22, '', 0, '', 0),
(24, 'eggz', 40, '3000', 0),
(25, 'eggz', 20, '150000', 0),
(26, 'eggz', 20, '150000', 0),
(28, 'green paper', 11, '1111111', 12),
(29, '', 0, '', 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `role`, `password`) VALUES
('caro', 'farmer', 'caro1'),
('lydia', 'customer', 'lydia2');
